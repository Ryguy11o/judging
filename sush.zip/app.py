import csv
import operator

def Average(lst): 
    return sum(lst) / len(lst) 

with open('./scores.csv', errors='ignore') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0

    team_num_to_score = {};
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:

            total = int(row[3]) + int(row[4]) + int(row[5]) + int(row[6]) + int(row[7])

            team_num_to_score.setdefault(row[2], [total]).append(total)
            print(f'\t Team Name: {row[1]} Table Number: {row[2]}, Total: {total}')
            line_count += 1

    print("it's happening")
    use_me = {}
    for key, value in team_num_to_score.items():
        use_me[key] = Average(value);
        print(f' Team Number: {key}, Average Score: {Average(value)}, Number of Hits: {len(value)}')

    sorted_x = sorted(use_me.items(), key=operator.itemgetter(1))

    print(sorted_x)